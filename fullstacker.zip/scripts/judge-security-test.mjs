#!/usr/bin/env node
import assert from "node:assert/strict";

const challenge = {
  id: "t",
  type: "js-function",
  title: "t",
  prompt: "t",
  difficulty: "easy",
  timeLimitSec: 60,
  starter: "",
  functionName: "add",
  tests: [{ name: "1+1", args: [1, 1], expected: 2 }],
};

async function main() {
  let judgeSubmission;
  try {
    ({ judgeSubmission } = await import("../src/lib/duel/judge.ts"));
  } catch (e) {
    console.error("Need Node with TS or run: npx tsx scripts/judge-security-test.mjs");
    console.error(e.message);
    process.exit(1);
  }

  const ok = judgeSubmission(challenge, "function add(a,b){return a+b}");
  assert.equal(ok.ok, true, ok.report);

  const blocked = judgeSubmission(
    challenge,
    "function add(a,b){return require('fs').readFileSync('/etc/passwd','utf8')}",
  );
  assert.equal(blocked.ok, false);
  assert.match(blocked.report, /require|запрещ/i);

  const evalBlocked = judgeSubmission(
    challenge,
    "function add(a,b){return eval('1+1')}",
  );
  assert.equal(evalBlocked.ok, false);

  console.log("ok judge security");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
