#!/usr/bin/env node
/**
 * Pre-deploy gate: required env present + security smoke (if server up) + build.
 *
 *   npm run predeploy
 */
import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";

function fail(msg) {
  console.error("predeploy FAIL:", msg);
  process.exit(1);
}

const envPath = ".env.local";
if (!existsSync(envPath) && !process.env.CI) {
  console.warn("warn: нет .env.local (на CI ожидаются env хостинга)");
}

function hasEnv(name) {
  if (process.env[name]) return true;
  if (!existsSync(envPath)) return false;
  const raw = readFileSync(envPath, "utf8");
  return new RegExp(`^${name}=.+`, "m").test(raw);
}

const required = [
  ["NEXT_PUBLIC_SUPABASE_URL", "SUPABASE_URL"],
  ["NEXT_PUBLIC_SUPABASE_ANON_KEY", "SUPABASE_PUBLISHABLE_KEY"],
  ["SUPABASE_SERVICE_ROLE_KEY", "SUPABASE_SECRET_KEY"],
  ["ADMIN_EMAIL"],
];

for (const group of required) {
  if (!group.some((name) => hasEnv(name))) {
    fail(`нужна одна из переменных: ${group.join(" | ")}`);
  }
}

const migrations = [
  "001_user_progress.sql",
  "002_profile_on_signup.sql",
  "003_roles_plans_duels.sql",
  "004_profile_email_admin.sql",
  "005_duel_rooms.sql",
];
for (const file of migrations) {
  if (!existsSync(`supabase/migrations/${file}`)) {
    fail(`нет миграции ${file}`);
  }
}
console.log("ok env + migrations present");

function run(cmd, args, opts = {}) {
  const res = spawnSync(cmd, args, {
    stdio: "inherit",
    shell: false,
    ...opts,
  });
  if (res.status !== 0) fail(`${cmd} ${args.join(" ")}`);
}

run("npm", ["run", "test:judge"]);

const smoke = spawnSync("npm", ["run", "test:security"], { stdio: "inherit" });
if (smoke.status !== 0) {
  console.warn(
    "warn: security smoke не прошёл (подними `npm run dev` или проверь BASE_URL)",
  );
}

run("npm", ["run", "build"]);
console.log("predeploy OK");
